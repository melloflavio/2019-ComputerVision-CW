%%
% colorImage = imread('../Dataset\test_set\65\individual_pic\IMG_20190128_202419.jpg');
% filepath = '../Dataset\test_set\65\individual_pic\IMG_20190128_202419.jpg';
filepath = '../Dataset\test_set\65\individual_mov\IMG_20190128_202419.mp4';
detected = detectNum(filepath);

%%
% imagePath = "../Dataset\test_set\51\individual_pic\IMG_20190128_201924.jpg";
% imagePath = "../Dataset\test_set\65\individual_pic\IMG_20190128_202419.jpg";
imagePath = "../Dataset\test_set\group\individual_pic\IMG_8224.jpg";
imgObj = imread(imagePath);
% imshow(imgObj);

% acceptedClassifiers = {'SVM', 'CNN', 'RF', 'NB', 'KNN'};
% acceptedFeatureTypes = {'SURF', 'HOG'};
% result = RecogniseFace(imgObj, 'SURF', 'RF');
result = RecogniseFace(imgObj, 'SURF', 'CNN');

% Draw Circles around every face
annotatedImg = insertShape(imgObj, 'circle',[result(:, 2), result(:, 3), ones(size(result, 1), 1)*200], 'LineWidth', 5);
imshow(annotatedImg);

% Add labels to faces
for i = 1:size(result,1)
    text(result(i,2),result(i,3),num2str(result(i,1)), 'Color', 'red');
end


% featureType, classifierName)
        




%%

inputBasepath = "../Dataset\processed_5";
imgDatastore = imageDatastore(inputBasepath, 'IncludeSubfolders', true, 'LabelSource','foldernames');
for i=1:size(imgDatastore.Labels, 1)
    image = readimage(imgDatastore, i);
    fixImage = imresize(image,[227 227]);
    i
outName = imgDatastore.Files(i);
    imwrite(fixImage, outName{1});
end
%% Delete Half files

inputBasepath = "../Dataset\processed_5_half";
imgDatastore = imageDatastore(inputBasepath, 'IncludeSubfolders', true, 'LabelSource','foldernames');
for i=1:size(imgDatastore.Labels, 1)
    if (rem(i,2) == 0)
        filename = imgDatastore.Files(i);
        delete(filename{1});
    end
end






